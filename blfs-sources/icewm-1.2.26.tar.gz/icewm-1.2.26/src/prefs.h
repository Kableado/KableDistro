#ifndef __PREFS_H
#define __PREFS_H

#include "default.h"
#include "bindkey.h"

#endif
