#include "config.h"

#include "ylib.h"
#define CFGDEF

#include "yprefs.h"
