#ifndef __YLIB_H
#define __YLIB_H

#include "base.h"

#define __YIMP_XLIB__

#include <X11/X.h>
#include <X11/Xlib.h>

#endif
