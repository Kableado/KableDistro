#include <stdarg.h>

int main() {

va_list a, b;

a = b;
; return 0; }

