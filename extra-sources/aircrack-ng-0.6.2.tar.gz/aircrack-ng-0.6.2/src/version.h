#define _MAJ 0
#define _MIN 6
#define _SUB_MIN 2
#define _BETA 0
#define WEBSITE "http://www.aircrack-ng.org"
