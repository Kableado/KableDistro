#if __POWERPC__
#include "MW_TkBuildLibHeaderPPC"
#elif __CFM68K__
#include "MW_TkBuildLibHeaderCFM68K"
#else
#include "MW_TkBuildLibHeader68K"
#endif
